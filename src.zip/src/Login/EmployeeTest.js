




// import React, { Component } from 'react';

// class MyComponent extends Component {
//     constructor(props) {
//         super(props);
//         // 初始化状态
//         this.state = {
//             count: 0
//         };
//     }

//     // 自定义方法来更新状态
//     incrementCount = () => {
//         // 使用 setState 更新状态
//         this.setState(prevState => ({
//             count: prevState.count + 1
//         }));
//     };

//     render() {
//         // 从 props 和 state 中获取数据
//         const { name } = this.props;
//         const { count } = this.state;

//       //   const arr = [1,2,3,4,5]
//       //   let sum = 0

//       //   for (let index = 0; index < arr.length; index++) {
//       //     sum += arr[index];
//       //  }
//       //   console.log(sum)


//       // const numbers = [1, 2, 3, 4, 5];
//       // let sum = 0;

//       // // 使用 for 循环计算数组中所有值的总和
//       // for (let i = 0; i < numbers.length; i++) {
//       //     sum += numbers[i];
//       // }

//       // console.log(sum); // 输出: 15




      
//             const arrr= [1,2,3];
//             let sum = 0;

//             for (let i = 0; i <arrr.length; i++) {
//                 sum += arrr[i];

//             }
//             console.log(sum)



//             let arr1 = [4, 5, 6, 8, 9]
//             let num = 0;
            
//             // for(let i = 0; i<arr1.length; i++){
//             //     num += arr1[i];
//             // }

//             num = arr1.reduce((preVal, currentVal) => preVal + currentVal )

//             console.log('num------',num)


//             // const numbers = [1, 2, 3, 4, 5];

//             // // 使用 reduce 方法计算数组中所有值的总和
//             // const sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0);
            
//             // console.log(sum); // 输出: 15
            
















//         return (
//             <div>
//                 <h1>Hello, {name}!</h1>
//                 <p>Count: {count}</p>
//                 {/* 调用自定义方法来更新状态 */}
//                 <button onClick={this.incrementCount}>Increment</button>


      


//             </div>
//         );
//     }
// }

// export default MyComponent;
